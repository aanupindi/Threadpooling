1. This directory contains 3 source files: main.cpp, cardDeck.h and cardDeck.cpp
2. To compile this program, run "make" from the current directory.
3. To run this program "./cards > test.txt" to output all the data into a text file.
4. The program also prints out the number of shuffles that took place before the program exited.
	Use "tail test.txt" to get the number of shuffles.
5. The design and Implementation of the algorithm is described in the file Design_Doc.pdf
6. The additional questions are answered in the file Additional_Considerations.pdf