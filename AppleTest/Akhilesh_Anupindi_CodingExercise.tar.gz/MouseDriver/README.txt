1. The source is contained in the file mousepacket.c
2. To compile the file, type "make"
3. To run the program with the default test cases, type "./mouseDriver"